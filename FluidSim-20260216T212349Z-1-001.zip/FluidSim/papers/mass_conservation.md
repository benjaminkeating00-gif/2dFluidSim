Conservation of mass under symmetric inflow conditions in an incompressible Eulerian smoke model.

I suspect this is due to the interpolation of the Semi-Lagrangian scheme, though I'm not sure my model spans enough timesteps for this to be the case. 